import pytest


@pytest.fixture
def one():
    return 1 / 0
